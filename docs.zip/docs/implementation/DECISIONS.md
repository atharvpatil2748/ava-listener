# Decisions

## Implementation planning as code artifacts

Decision: Implementation planning and architecture tracking must live in repository documents, not in chat responses.

Rationale:
- version control captures design changes
- documentation becomes reviewable and auditable
- team members can inspect architecture without reading chat transcripts

Tradeoff:
- requires discipline to keep docs synchronized with code

## Bootstrap lock file

Decision: Add `bootstrap.lock` to prevent concurrent startup bootstrap operations.

Rationale:
- protects runtime install and model download flows from corruption
- enforces single-install semantics on first startup

## Cache-based runtime distribution

Decision: Use a user-local cache instead of packaging an embedded Python runtime with npm.

Rationale:
- avoids large package payloads
- supports fresh-machine bootstrap without bundling platform-specific Python
- allows runtime repair without modifying package contents

## Model downloads during runtime startup only

Decision: Model downloads may only occur during `listener.start()`.

Rationale:

## 2026-05-23 — Implementation updates

- Integrated runtime bootstrap using `RuntimeManager` and `BootstrapLock` into `Lifecycle.start()`.
- Implemented `ModelManager` for manifest-driven model verification and downloads with checksum validation.
