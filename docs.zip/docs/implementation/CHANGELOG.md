# Changelog

## 2026-05-23

- Created `docs/implementation/` package and tracking artifacts.
- Added `bootstrap.lock` artifact.
- Added runtime manager and model manager skeleton files in `node/`.
- Added startup flow and architecture documentation.
- Added runtime sources configuration and model manifest schema artifacts.
- Added metadata templates for runtime state, installed models, checksums, and bootstrap state.
- Added bootstrap state recovery behavior to startup flow.
- Added migration notes and phase tracker entry.

- 2026-05-23 (implementation)
	- Implemented `ModelManager` with manifest loading, checksum verification, local `file://` and remote download support, retry logic, and metadata persistence.
	- Integrated `RuntimeManager` bootstrap into `Lifecycle.start()` with `BootstrapLock` acquisition, verify/install flow, and safe release.
	- Added `verifyOrDownload()` wiring for model verification after runtime readiness.
